package com.mindtree.collegeandbranch.dto;

import java.util.List;
import java.util.Set;

import com.mindtree.collegeandbranch.entity.Branch;

public class CollegeDto {

	private int collegeId;
	private String collegeName;
	private String locationName;
	private int numberOfBranches;
	private Set<BranchDto> branchDto;

	public CollegeDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CollegeDto(int collegeId, String collegeName, String locationName, int numberOfBranches,
			Set<BranchDto> branchDto) {
		super();
		this.collegeId = collegeId;
		this.collegeName = collegeName;
		this.locationName = locationName;
		this.numberOfBranches = numberOfBranches;
		this.branchDto = branchDto;
	}

	public int getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public int getNumberOfBranches() {
		return numberOfBranches;
	}

	public void setNumberOfBranches(int numberOfBranches) {
		this.numberOfBranches = numberOfBranches;
	}

	public Set<BranchDto> getBranchDto() {
		return branchDto;
	}

	public void setBranchDto(Set<BranchDto> branchDto) {
		this.branchDto = branchDto;
	}

	@Override
	public String toString() {
		return "CollegeDto [collegeId=" + collegeId + ", collegeName=" + collegeName + ", locationName=" + locationName
				+ ", numberOfBranches=" + numberOfBranches + ", branchDto=" + branchDto + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((branchDto == null) ? 0 : branchDto.hashCode());
		result = prime * result + collegeId;
		result = prime * result + ((collegeName == null) ? 0 : collegeName.hashCode());
		result = prime * result + ((locationName == null) ? 0 : locationName.hashCode());
		result = prime * result + numberOfBranches;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollegeDto other = (CollegeDto) obj;
		if (branchDto == null) {
			if (other.branchDto != null)
				return false;
		} else if (!branchDto.equals(other.branchDto))
			return false;
		if (collegeId != other.collegeId)
			return false;
		if (collegeName == null) {
			if (other.collegeName != null)
				return false;
		} else if (!collegeName.equals(other.collegeName))
			return false;
		if (locationName == null) {
			if (other.locationName != null)
				return false;
		} else if (!locationName.equals(other.locationName))
			return false;
		if (numberOfBranches != other.numberOfBranches)
			return false;
		return true;
	}

}
