package com.mindtree.collegeandbranch.exception.exceptionhandler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mindtree.collegeandbranch.exception.ServiceException;

@ControllerAdvice
public class AppExceptionHandler {

	@ExceptionHandler
	public String CollegeLimitExceededException(ServiceException e, Model model) {
		Map<String, Object> error = new HashMap<String, Object>();
		error.put("message", e.getMessage());
		error.put("httpstatus", HttpStatus.BAD_REQUEST.value());
		model.addAttribute("error", error);
		return "error";

	}
}
