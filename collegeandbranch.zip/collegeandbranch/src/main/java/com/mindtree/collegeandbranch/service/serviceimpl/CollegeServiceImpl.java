package com.mindtree.collegeandbranch.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.collegeandbranch.dto.CollegeDto;
import com.mindtree.collegeandbranch.entity.College;
import com.mindtree.collegeandbranch.repository.CollegeRepository;
import com.mindtree.collegeandbranch.service.CollegeService;

@Service
public class CollegeServiceImpl implements CollegeService {

	@Autowired
	private CollegeRepository collegeRepository;

	ModelMapper mapper = new ModelMapper();

	@Override
	public String addCollege(CollegeDto collegeDto) {
		// TODO Auto-generated method stub
		College college = mapper.map(collegeDto, College.class);
		collegeRepository.save(college);
		return "inserted successfully";
	}

	@Override
	public List<CollegeDto> getCollegeDetails() {
		// TODO Auto-generated method stub
		List<College> collegeDetails = collegeRepository.findAll();
		List<CollegeDto> collegeDto = new ArrayList<CollegeDto>();
		for (College c : collegeDetails) {
			CollegeDto college = mapper.map(c, CollegeDto.class);
			collegeDto.add(college);

		}
		return collegeDto;
	}

}
