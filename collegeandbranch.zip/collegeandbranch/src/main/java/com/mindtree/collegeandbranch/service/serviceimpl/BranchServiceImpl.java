package com.mindtree.collegeandbranch.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.collegeandbranch.dto.BranchDto;
import com.mindtree.collegeandbranch.entity.Branch;
import com.mindtree.collegeandbranch.entity.College;
import com.mindtree.collegeandbranch.exception.CollegeListExceededException;
import com.mindtree.collegeandbranch.exception.ServiceException;
import com.mindtree.collegeandbranch.repository.BranchRepository;
import com.mindtree.collegeandbranch.repository.CollegeRepository;
import com.mindtree.collegeandbranch.service.BranchService;

@Service
public class BranchServiceImpl implements BranchService {

	@Autowired
	private BranchRepository branchRepository;
	@Autowired
	private CollegeRepository collegeRepository;

	ModelMapper mapper = new ModelMapper();

	@Override
	public String addBranchDetails(BranchDto branchDto, String collegeName) throws ServiceException {
		// TODO Auto-generated method stub
		List<College> colleges = collegeRepository.findAll();
		Branch branch = mapper.map(branchDto, Branch.class);
		College c1 = colleges.stream().filter(i -> i.getCollegeName().equalsIgnoreCase(collegeName)).findAny().get();

		Set<Branch> branch1 = c1.getBranch();
		if (branch1.size() < c1.getNumberOfBranches()) {
			c1.getBranch().add(branch);
			collegeRepository.save(c1);
		} else {
			throw new CollegeListExceededException("Branch limit exceeded");
		}
		return "inserted successfully";
	}

	@Override
	public List<BranchDto> getDetails(String collegeName) {
		// TODO Auto-generated method stub

		College college = collegeRepository.findBycollegeName(collegeName);
		Set<Branch> branches = college.getBranch();
		List<BranchDto> branchDtoDetails = new ArrayList<BranchDto>();
		for (Branch b : branches) {
			BranchDto branchDto = mapper.map(b, BranchDto.class);
			branchDtoDetails.add(branchDto);
		}
		return branchDtoDetails;
	}

	@Override
	public String updateDetailsForm(int branchId1, int branchtotalStrength) {
		// TODO Auto-generated method stub
		Branch branch = branchRepository.findById(branchId1).get();
		branch.setTotalStrength(branchtotalStrength);
		branchRepository.saveAndFlush(branch);
		return "updated successfully";
	}

}
