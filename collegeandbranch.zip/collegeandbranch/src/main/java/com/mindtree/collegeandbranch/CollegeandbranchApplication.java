package com.mindtree.collegeandbranch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeandbranchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeandbranchApplication.class, args);
	}

}
