package com.mindtree.collegeandbranch.dto;

public class BranchDto {

	private int branchId;
	private String branchName;
	private int totalStrength;
	private String hodName;

	public BranchDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BranchDto(int branchId, String branchName, int totalStrength, String hodName) {
		super();
		this.branchId = branchId;
		this.branchName = branchName;
		this.totalStrength = totalStrength;
		this.hodName = hodName;
	}

	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public int getTotalStrength() {
		return totalStrength;
	}

	public void setTotalStrength(int totalStrength) {
		this.totalStrength = totalStrength;
	}

	public String getHodName() {
		return hodName;
	}

	public void setHodName(String hodName) {
		this.hodName = hodName;
	}

	@Override
	public String toString() {
		return "BranchDto [branchId=" + branchId + ", branchName=" + branchName + ", totalStrength=" + totalStrength
				+ ", hodName=" + hodName + "]";
	}

}
