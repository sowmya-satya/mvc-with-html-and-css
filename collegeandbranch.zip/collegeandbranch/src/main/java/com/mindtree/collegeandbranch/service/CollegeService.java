package com.mindtree.collegeandbranch.service;

import java.util.List;

import com.mindtree.collegeandbranch.dto.CollegeDto;

public interface CollegeService {

	/**
	 * @param collegeDto
	 * @return
	 */
	String addCollege(CollegeDto collegeDto);

	List<CollegeDto> getCollegeDetails();

}
