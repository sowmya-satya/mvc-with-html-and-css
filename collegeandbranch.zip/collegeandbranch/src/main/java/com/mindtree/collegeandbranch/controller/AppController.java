package com.mindtree.collegeandbranch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.collegeandbranch.dto.BranchDto;
import com.mindtree.collegeandbranch.dto.CollegeDto;
import com.mindtree.collegeandbranch.exception.ServiceException;
import com.mindtree.collegeandbranch.service.BranchService;
import com.mindtree.collegeandbranch.service.CollegeService;

@Controller
public class AppController {

	@Autowired
	private CollegeService collegeService;
	@Autowired
	private BranchService branchService;
	BranchDto branch1 = new BranchDto();

	@RequestMapping("/")
	public String home() {
		return "home";
	}

	@RequestMapping("/college")
	public String college() {
		return "college";
	}

	@RequestMapping("/addCollege")
	public String addCollege(CollegeDto collegeDto) {
		collegeService.addCollege(collegeDto);
		return "home";
	}

	@RequestMapping("/branch")
	public String branch(Model model) {
		model.addAttribute("college", collegeService.getCollegeDetails());
		return "branch";
	}

	@RequestMapping("/addBranch")
	public String addBranch(BranchDto branchDto, @RequestParam String collegeName) throws ServiceException {
		branchService.addBranchDetails(branchDto, collegeName);
		return "message";
	}

	@RequestMapping("/view")
	public String view(Model model) {
		model.addAttribute("college", collegeService.getCollegeDetails());
		return "view";
	}

	@RequestMapping(path = "/getDetails")
	public String getDetails(Model model, @RequestParam String collegeName) {
		model.addAttribute("branch", branchService.getDetails(collegeName));
		model.addAttribute("college", collegeService.getCollegeDetails());

		return "view";
	}

	int branchId1 = 0;

	@RequestMapping("/update/{branchId}/{totalStrength}")
	public String updateDetails(@PathVariable int branchId, Model model, @PathVariable int totalStrength) {

		branchId1 = branchId;
		model.addAttribute("totalStrength", totalStrength);
		return "update";
	}

	@RequestMapping("/updatedetails")
	public String updateStrengthDetails(@RequestParam int totalStrength, Model model) {

		branchService.updateDetailsForm(branchId1, totalStrength);

		return "message";

	}
}