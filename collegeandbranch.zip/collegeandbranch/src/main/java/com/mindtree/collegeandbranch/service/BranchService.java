package com.mindtree.collegeandbranch.service;

import java.util.List;

import com.mindtree.collegeandbranch.dto.BranchDto;
import com.mindtree.collegeandbranch.exception.ServiceException;

public interface BranchService {

	/**
	 * @param branchDto
	 * @param collegeName
	 * @return
	 * @throws ServiceException
	 */
	String addBranchDetails(BranchDto branchDto, String collegeName) throws ServiceException;

	/**
	 * @param collegeName
	 * @return
	 */
	List<BranchDto> getDetails(String collegeName);

	/**
	 * @param branchId1
	 * @param branchtotalStrength
	 * @return
	 */
	String updateDetailsForm(int branchId1, int branchtotalStrength);

}
